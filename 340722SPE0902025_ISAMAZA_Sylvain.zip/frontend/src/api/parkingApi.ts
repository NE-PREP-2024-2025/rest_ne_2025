import axiosInstance from './axiosInstance';

export interface ParkingListParams {
  page?: number;
  limit?: number;
  search?: string;
  startDate?: string;
  endDate?: string;
}

export interface ParkingLot {
  code: string;
  parkingName: string;
  location: string;
  numberOfAvailableSpace: number;
  feesPerHour: number;
  createdAt: string;
  updatedAt: string;
}

export interface ParkingTicket {
  id: string;
  plateNumber: string;
  parking_code: string;
  entry_date: string;
  exit_date: string | null;
  amount: number | null;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateParkingLotRequest {
  parkingName: string;
  location: string;
  numberOfAvailableSpace: number;
  feesPerHour: number;
}

export interface UpdateParkingLotRequest extends Partial<CreateParkingLotRequest> {}

export interface CreateParkingTicketRequest {
  plateNumber: string;
  parkingCode: string;
}

const parkingApi = {
  // Parking Lots
  getParkingLots: (params?: ParkingListParams) => 
    axiosInstance.get('/parking/all', { params }).then(res => res.data),
  
  getParkingLotByCode: (code: string) => 
    axiosInstance.get(`/parking/${code}`).then(res => res.data),
  
  createParkingLot: (data: CreateParkingLotRequest) => 
    axiosInstance.post('/parking/', data).then(res => res.data),
  
  updateParkingLot: (code: string, data: UpdateParkingLotRequest) => 
    axiosInstance.put(`/parking/${code}`, data).then(res => res.data),
  
  deleteParkingLot: (code: string) => 
    axiosInstance.delete(`/parking/${code}`).then(res => res.data),

  // Parking Tickets
  getParkingTickets: (params?: ParkingListParams) => 
    axiosInstance.get('/parking-ticket/', { params }).then(res => res.data),
  
  getAllParkingTickets: (params?: ParkingListParams) => 
    axiosInstance.get('/parking-ticket/all', { params }).then(res => res.data),
  
  createParkingTicket: (data: CreateParkingTicketRequest) => 
    axiosInstance.post('/parking-ticket/', data).then(res => res.data),
  
  generateBill: (id: string) => 
    axiosInstance.post(`/parking-ticket/generate-bill/${id}`).then(res => res.data),

  // Reports
  getCarEntryReport: (params?: ParkingListParams) =>
    axiosInstance.get('/report/car-entry-report', { params }).then(res => res.data),

  deleteTicket: (id: string) =>
    axiosInstance.delete(`/parking-ticket/${id}`).then(res => res.data),

  getCarExitReport: (params?: ParkingListParams) =>
    axiosInstance.get('/report/car-exit-report', { params }).then(res => res.data),
};

export default parkingApi;
