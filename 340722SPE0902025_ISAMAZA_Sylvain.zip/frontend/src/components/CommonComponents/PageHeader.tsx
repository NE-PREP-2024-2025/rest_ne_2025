
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Plus } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  actionDisabled?: boolean;
  className?: string;
  children?: React.ReactNode;
}

export function PageHeader({
  title,
  description,
  actionLabel,
  onAction,
  actionDisabled = false,
  className,
  children,
}: PageHeaderProps) {
  return (
    <div className={cn('mb-8', className)}>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">{title}</h1>
          {description && (
            <p className="text-muted-foreground max-w-[700px]">{description}</p>
          )}
        </div>

        {onAction && actionLabel && (
          <Button
            onClick={onAction}
            disabled={actionDisabled}
            size="sm"
            className="h-9 px-4 gap-1.5 shadow-sm transition-all duration-200 hover:scale-105"
          >
            <Plus className="h-4 w-4" />
            {actionLabel}
          </Button>
        )}
        
        {children && <div className="flex items-center gap-4">{children}</div>}
      </div>
    </div>
  );
}
