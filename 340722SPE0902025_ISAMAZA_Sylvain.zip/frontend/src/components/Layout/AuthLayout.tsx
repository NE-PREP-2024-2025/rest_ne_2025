
import { Outlet } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Car } from 'lucide-react';

interface AuthLayoutProps {
  className?: string;
}

export function AuthLayout({ className }: AuthLayoutProps) {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
      <div className="h-full flex flex-1 flex-col items-center justify-center p-4">

        <div className={cn(
          'w-full max-w-md p-8 bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-border/50 animate-scale-in',
          className
        )}>
                  <div className=" pb-4 top-8 flex flex-col items-center">
        <div className="flex items-center gap-2">
            <div className="w-16 h-16 rounded-full ">
              <img src="/logo.png" alt="XWZ Logo" className='rounded-full' />
            </div>
            </div>
          <p className=" font-bold text-center max-w-md">
            XWZ Parking management
          </p>
        </div>
          <Outlet />
        </div>
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>© 2025 XWZ LTD All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
