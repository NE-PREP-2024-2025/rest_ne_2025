
import { useState, useEffect } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Car,
  User,
  Users,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  ListChecks,
  ParkingCircleIcon,
  Calendar,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from '@/components/ui/tooltip';

interface SidebarItemProps {
  icon: React.ElementType;
  label: string;
  to: string;
  isCollapsed: boolean;
  badge?: number;
}

const SidebarItem = ({ icon: Icon, label, to, isCollapsed, badge }: SidebarItemProps) => {
  const location = useLocation();
  const isActive = location.pathname === to || location.pathname.startsWith(`${to}/`);

  return (
    <TooltipProvider delayDuration={0}>
      <Tooltip>
        <TooltipTrigger asChild>
          <NavLink
            to={to}
            className={
              cn(
                'flex items-center gap-3 rounded-lg px-3 py-2.5 transition-all duration-200 group relative',
                isActive
                  ? 'bg-primary text-primary-foreground dark:bg-primary/80'
                  : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
              )
            }
          >
            <Icon className={cn(
              "h-5 w-5 flex-shrink-0",
              isCollapsed && "mx-auto"
            )} />
            {!isCollapsed && (
              <>
                <span className="truncate font-medium">{label}</span>
                {badge && badge > 0 ? (
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 ml-auto flex h-5 min-w-[20px] items-center justify-center rounded-full bg-primary/10 text-primary text-xs px-1">
                    {badge}
                  </span>
                ) : null}
              </>
            )}
          </NavLink>
        </TooltipTrigger>
        {isCollapsed && (
          <TooltipContent side="right">
            {label}
            {badge && badge > 0 ? ` (${badge})` : null}
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );
};

export function DashboardLayout() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { logout, user } = useAuth();
  const location = useLocation();

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const sidebarItems = [

    { icon: ParkingCircleIcon, label: 'Parking', to: '/admin/parking', badge: 0 },
    { icon: ListChecks, label: 'Reports', to: '/admin/reports', badge: 0 },
    { icon: Calendar, label: 'Tickets', to: '/admin/tickets', badge: 0 },
    { icon: Users, label: 'Users', to: '/admin/users', badge: 0 },
    { icon: User, label: 'My Profile', to: '/admin/profile', badge: 0 }
   
  ];

  const initials = user ? `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}` : 'PS';

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
       {!isMobileMenuOpen&&<Button size="icon" variant="outline" onClick={toggleMobileMenu}
          className={`${!isMobileMenuOpen?"h-10 w-10 bg-background/80 backdrop-blur-sm border-border/40":"bg-transparent"} `}
        >
          {isMobileMenuOpen ? <div></div> : <Menu className="h-5 w-5" />}
        </Button>}
      </div>

      {/* Mobile sidebar overlay */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm transition-all duration-200 animate-fade-in">
          {/* Mobile sidebar */}
          <div className="fixed inset-y-0 left-0 w-80 bg-background border-r shadow-lg p-4 animate-slide-in">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                 <div className="w-16 h-16 rounded-full ">
              <img src="/logo.png" alt="ParkSmart Logo" className='rounded-full' />
           </div>
                </div>
                <Button size="icon" variant="ghost" onClick={toggleMobileMenu}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <div className="flex flex-col gap-1 mt-2">
                {sidebarItems.map((item) => (
                  <SidebarItem
                    key={item.to}
                    icon={item.icon}
                    label={item.label}
                    to={item.to}
                    isCollapsed={false}
                    badge={item.badge}
                  />
                ))}
              </div>
              <div className="mt-auto">
                <Separator className="my-4" />
                <div className="flex items-center gap-3 mb-6">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user?.profileImage} />
                    <AvatarFallback>{initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">{user?.firstName} {user?.lastName}</span>
                    <span className="text-xs text-muted-foreground">{user?.email}</span>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                  onClick={() => logout()}
                >
                  <LogOut className="mr-2 h-5 w-5" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <div
        className={cn(
          'hidden lg:flex flex-col border-r bg-background/50 backdrop-blur-sm transition-all duration-200',
          isCollapsed ? 'w-[70px]' : 'w-[240px]'
        )}
      >
        <div className={cn("flex py-3  items-center border-b px-4", isCollapsed && "justify-center")}>
          {!isCollapsed ? (
            <div className="flex items-center gap-2">
              <div className="w-16 h-16 rounded-full ">
              <img src="/logo.png" alt="ParkSmart Logo" className='rounded-full' />
              </div>
              Park Smart
            </div>
          ) : (
            <Car className="h-6 w-6 text-primary" />
          )}
        </div>
        
        <div className="flex flex-col flex-1 p-2 overflow-y-auto">
          <div className="space-y-1">
            {sidebarItems.map((item) => (
              <SidebarItem
                key={item.to}
                icon={item.icon}
                label={item.label}
                to={item.to}
                isCollapsed={isCollapsed}
                badge={item.badge}
              />
            ))}
          </div>
          
          <div className="mt-auto pt-4">
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                'w-full justify-center border border-dashed border-border/50 hover:bg-muted/80',
                !isCollapsed && 'justify-between'
              )}
              onClick={toggleSidebar}
            >
              {!isCollapsed ? (
                <>
                  <span className="text-xs">Collapse</span>
                  <ChevronLeft className="h-4 w-4" />
                </>
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
            
            <Separator className="my-4" />
            
            {!isCollapsed ? (
              <div className="flex items-center gap-3 mb-4 px-2">
                <Avatar className="h-9 w-9">
                  <AvatarImage src={user?.profileImage} />
                  <AvatarFallback>{initials}</AvatarFallback>
                </Avatar>
                <div className="flex flex-col overflow-hidden">
                  <span className="font-medium text-sm truncate">{user?.firstName} {user?.lastName}</span>
                  <span className="text-xs text-muted-foreground truncate">{user?.email}</span>
                </div>
              </div>
            ) : (
              <div className="flex justify-center mb-4">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={user?.profileImage} />
                        <AvatarFallback>{initials}</AvatarFallback>
                      </Avatar>
                    </TooltipTrigger>
                    <TooltipContent side="right">
                      <p>{user?.firstName} {user?.lastName}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            )}

            <Button
              variant="ghost"
              className={cn(
                'w-full mt-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10',
                isCollapsed ? 'justify-center px-0' : 'justify-start'
              )}
              onClick={() => logout()}
            >
              <LogOut className={cn('h-5 w-5', !isCollapsed && 'mr-2')} />
              {!isCollapsed && <span>Logout</span>}
            </Button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="flex-1 overflow-auto bg-muted/20">
        <div className="flex flex-col h-full">
      
          
          <div className="flex-1 overflow-auto">
            <div className="container py-6 w-full">
              <Outlet />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
