import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import { Login } from "./pages/auth/Login";
import { Register } from "./pages/auth/Register";
import { ForgotPassword } from "./pages/auth/ForgotPassword";
import { ResetPassword } from "./pages/auth/ResetPassword";
import { AuthLayout } from "./components/Layout/AuthLayout";
import { AuthProvider } from "./hooks/useAuth";
import { DashboardLayout } from "./components/Layout/DashboardLayout";
import { UserDashboardLayout } from "./components/Layout/UserDashboardLayout";
import { ParkList } from "./pages/admin/Park/ParkList";
import { UsersList } from "./pages/admin/Users/UsersList";
import { AdminProfile } from "./pages/admin/Profile/AdminProfile";
import { UserProfile } from "./pages/user/Profile/UserProfile";
import { useState } from "react";
import { UserParkingList } from "./pages/user/Parks/ParkList";
import TicketList from "./pages/admin/Tickets/TicketList";
import UserTicketList from "./pages/user/Tickets/TicketList";
import Report from "./pages/admin/Report/Report";


const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

const App = () => {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedId, setSelectedId] = useState("");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner position="top-right" closeButton={true} richColors />
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              <Route path="/" element={<Index />} />

              {/* Auth Routes */}
              <Route element={<AuthLayout />}>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route
                  path="/reset-password/:token"
                  element={<ResetPassword />}
                />
              </Route>

              {/* Admin Dashboard Routes */}
              <Route element={<DashboardLayout />}>
                <Route path="/admin/home" element={<Navigate to="/admin/parking" replace />} />

  

                {/* Parking Management */}
                <Route path="/admin/parking" element={<ParkList />} />
                <Route path="/admin/tickets" element={<TicketList />} />
                <Route path="/admin/reports" element={<Report />} />
                <Route path="/admin/parks" element={<Navigate to="/admin/parking" replace />} />
                <Route path="/admin/users" element={<UsersList />} />
                <Route
                  path="/admin/profile"
                  element={<AdminProfile />}
                />
              </Route>

              {/* User Dashboard Routes */}
              <Route element={<UserDashboardLayout />}>
                <Route path="/user/dashboard" element={<Navigate to="/user/parking" replace />} />
                <Route path="/user/parking" element={<UserParkingList />} />
                <Route path="/user/tickets" element={<UserTicketList />} />
                <Route path="/user/profile" element={<UserProfile />} />
              </Route>

    
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
