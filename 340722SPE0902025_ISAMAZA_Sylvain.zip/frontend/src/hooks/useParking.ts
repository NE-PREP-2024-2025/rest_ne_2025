
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import parkingApi, { 
  ParkingListParams, 
  CreateParkingLotRequest, 
  UpdateParkingLotRequest,
  CreateParkingTicketRequest,
} from '../api/parkingApi';
import { toast } from 'sonner';

// Parking Lot Hooks
export const useParkingLots = (params: ParkingListParams = {}) => {
  return useQuery({
    queryKey: ['parkingLots', params],
    queryFn: () => parkingApi.getParkingLots(params)
  });
};
// Parking Lot by code  
export const useParkingLot = (code: string) => {
  return useQuery({
    queryKey: ['parkingLot', code],
    queryFn: () => parkingApi.getParkingLotByCode(code),
    enabled: !!code
  });
};

// Create Parking Lot hook
export const useCreateParkingLot = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: CreateParkingLotRequest) => parkingApi.createParkingLot(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parkingLots'] });
      toast.success('Parking lot created successfully');
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to create parking lot');
    }
  });
};

// Update Parking Lot hook
export const useUpdateParkingLot = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ code, data }: { code: string; data: UpdateParkingLotRequest }) => 
      parkingApi.updateParkingLot(code, data),
    onSuccess: (_, { code }) => {
      queryClient.invalidateQueries({ queryKey: ['parkingLots'] });
      queryClient.invalidateQueries({ queryKey: ['parkingLot', code] });
      toast.success('Parking lot updated successfully');
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to update parking lot');
    }
  });
};

// Delete Parking Lot hook
export const useDeleteParkingLot = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (code: string) => parkingApi.deleteParkingLot(code),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parkingLots'] });
      toast.success('Parking lot deleted successfully');
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to delete parking lot');
    }
  });
};

// Delete Parking Ticket hook
export const useDeleteParkingTicket = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (id: string) => parkingApi.deleteTicket(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parkingTickets'] });
      toast.success('Parking ticket deleted successfully');
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to delete parking ticket');
    }
  });
};

// Parking Ticket Hooks
export const useParkingTickets = (params: ParkingListParams = {}) => {
  return useQuery({
    queryKey: ['parkingTickets', params],
    queryFn: () => parkingApi.getParkingTickets(params)
  });
};

// Get All Parking Tickets hook
export const useAllParkingTickets = (params: ParkingListParams = {}) => {
  return useQuery({
    queryKey: ['allParkingTickets', params],
    queryFn: () => parkingApi.getAllParkingTickets(params)
  });
};

// Get Car Entry Report hook
export const useCarEntryReport = (params: ParkingListParams = {}) => {
  return useQuery({
    queryKey: ['carEntryReport', params],
    queryFn: () => parkingApi.getCarEntryReport(params),
    enabled: !!params.startDate && !!params.endDate
  });
};

// Get Car Exit Report hook
export const useCarExitReport = (params: ParkingListParams = {}) => {
  return useQuery({
    queryKey: ['carExitReport', params],
    queryFn: () => parkingApi.getCarExitReport(params),
    enabled: !!params.startDate && !!params.endDate
  });
};

// Create Parking Ticket hook
export const useCreateParkingTicket = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: CreateParkingTicketRequest) => 
      parkingApi.createParkingTicket(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parkingTickets'] });
      queryClient.invalidateQueries({ queryKey: ['allParkingTickets'] });
      toast.success('Parking ticket created successfully');
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to create parking ticket');
    }
  });
};

// Generate Bill hook
export const useGenerateBill = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (id: string) => parkingApi.generateBill(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parkingTickets'] });
      queryClient.invalidateQueries({ queryKey: ['allParkingTickets'] });
      toast.success('Bill generated successfully');
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to generate bill');
    }
  });
};
