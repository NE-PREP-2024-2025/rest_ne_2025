
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { Car, CalendarCheck, MapPin, UserCheck, ArrowRight, CheckCircle, Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export default function Index() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate(user?.role === 'ADMIN' ? '/admin/home' : '/user/dashboard');
    } else {
      navigate('/login');
    }
  };
  


  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex py-4 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-16 h-16 rounded-full ">
              <img src="/logo.png" alt="ParkSmart Logo" className='rounded-full' />
           </div>
          </div>
          
          {/* Desktop Navigation */}
         
          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            <span className="sr-only">Toggle menu</span>
          </Button>
          
          {/* Auth Buttons */}
          <div className="hidden md:flex items-center gap-2">
            {isAuthenticated ? (
              <Button
                onClick={() => navigate(user?.role === 'ADMIN' ? '/admin/home' : '/user/dashboard')}
              >
                Dashboard
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <>
                <Button variant="ghost" onClick={() => navigate('/login')}>
                  Login
                </Button>
                <Button onClick={() => navigate('/register')}>
                  Register
                </Button>
              </>
            )}
          </div>
        </div>
      </header>
      
      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-16 z-30 grid h-[calc(100vh-4rem)] grid-flow-row auto-rows-max overflow-auto bg-background p-6 pb-32 shadow-md animate-in md:hidden">
          <div className="flex flex-col space-y-4">
            <div className="pt-4 flex flex-col gap-2">
              {isAuthenticated ? (
                <Button
                  onClick={() => {
                    navigate(user?.role === 'ADMIN' ? '/admin/home' : '/user/dashboard');
                    setMobileMenuOpen(false);
                  }}
                >
                  Dashboard
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      navigate('/login');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Login
                  </Button>
                  <Button 
                    onClick={() => {
                      navigate('/register');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Register
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="w-full flex-1 bg-muted/50 py-12 md:py-24 lg:py-32 relative overflow-hidden">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4 lg:space-y-6">
              <div className="inline-block mb-4 rounded-lg bg-primary/10 px-3 py-1.5 text-sm font-medium text-primary">
                Smart Parking Solution
              </div>
              <h1 className="text-3xl md:text-5xl font-bold tracking-tight">
                Parking Made <span className="text-primary">Smart</span> and Simple
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                ParkSmart makes parking hassle-free. Find, reserve, and manage parking spaces with ease and confidence.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 pt-3">
                <Button
                  size="lg"
                  onClick={handleGetStarted}
                  className="bg-primary hover:bg-primary/90 text-white font-medium rounded-lg"
                >
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
      
              </div>
            </div>
            <div className="relative lg:ml-auto mx-auto w-full max-w-[500px] overflow-hidden rounded-xl shadow-xl">
              <img src='/logo.png' className="aspect-[16/9] object-cover bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center">
              
              </img>
              <div className="absolute inset-0 rounded-xl ring-1 ring-inset ring-black/10"></div>
            </div>
          </div>
        </div>
      </section>



     





    </div>
  );
}
