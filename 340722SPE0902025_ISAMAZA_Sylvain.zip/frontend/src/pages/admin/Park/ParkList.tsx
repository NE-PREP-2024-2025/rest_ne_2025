import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/CommonComponents/PageHeader";
import { useParkingLots, useDeleteParkingLot } from "@/hooks/useParking";
import { DataTable, Column } from "@/components/DataTable/DataTable";
import { ParkingLot } from "@/api/parkingApi";
import { Button } from "@/components/ui/button";
import { Edit, Trash, ParkingCircle, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { toast } from "sonner";
import { CreateParking } from "./CreateParking";

export function ParkList() {
  const navigate = useNavigate();
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [parkingToDelete, setParkingToDelete] = useState<ParkingLot | null>(null);
  
  const deleteParkingLot = useDeleteParkingLot();
  const { data, isLoading } = useParkingLots({
    page: pageIndex + 1,
    limit: pageSize,
    search,
  });

  const handleDeleteClick = (parking: ParkingLot) => {
    setParkingToDelete(parking);
  };

  const handleEditClick = (parking: ParkingLot) => {
    navigate(`/admin/parking/edit/${parking.code}`);
  };

  const handleConfirmDelete = async () => {
    if (parkingToDelete) {
      try {
        await deleteParkingLot.mutateAsync(parkingToDelete.code);
        setParkingToDelete(null);
        toast.success('Parking lot deleted successfully');
      } catch (error) {
        toast.error("Failed to delete parking lot");
      }
    }
  };

  const handleCreateClick = () => {
    setIsCreateModalOpen(true);
  };

  const columns: Column<ParkingLot>[] = [
    {
      header: "Code",
      accessorKey: "code",
      cell: (parking) => (
        <div className="flex items-center gap-2">
          <ParkingCircle className="h-4 w-4" />
          <span className="font-medium">{parking.code}</span>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Name",
      accessorKey: "parkingName",
      sortable: true,
    },
    {
      header: "Location",
      accessorKey: "location",
      sortable: true,
    },
    {
      header: "Available Spaces",
      accessorKey: "numberOfAvailableSpace",
      cell: (parking) => (
        <span className="font-medium">{parking.numberOfAvailableSpace}</span>
      ),
    },
    {
      header: "Hourly Rate",
      accessorKey: "feesPerHour",
      cell: (parking) => (
        <span>{parking.feesPerHour.toFixed(2)} RWF</span>
      ),
      sortable: true,
    },
    {
      header: "Created",
      accessorKey: "createdAt",
      cell: (parking) => format(new Date(parking.createdAt), 'MMM d, yyyy'),
      sortable: true,
    },
    {
      header: "Actions",
      accessorKey: "actions",
      cell: (parking) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              handleEditClick(parking);
            }}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              handleDeleteClick(parking);
            }}
          >
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <PageHeader
            title="Parking Lots"
            description="Manage parking lots in the system"
          />
          <Button onClick={handleCreateClick}>
            <Plus className="mr-2 h-4 w-4" />
            Add Parking Lot
          </Button>
        </div>

        <DataTable
          columns={columns}
          data={data?.data || []}
          totalItems={data?.totalItems || 0}
          pageIndex={pageIndex}
          pageSize={pageSize}
          onPageChange={setPageIndex}
          onPageSizeChange={setPageSize}
          onSearch={setSearch}
          searchPlaceholder="Search parking lots..."
          isLoading={isLoading}
        />
      </div>

      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent>
          <CreateParking
            open={isCreateModalOpen}
            openChange={setIsCreateModalOpen}
          />
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!parkingToDelete}
        onOpenChange={(open) => !open && setParkingToDelete(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Parking Lot</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this parking lot? This action cannot be
              undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setParkingToDelete(null)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmDelete}
              disabled={deleteParkingLot.isPending}
            >
              {deleteParkingLot.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
