import { useState } from "react";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate, useParams } from "react-router-dom";
import { useCreateParkingLot, useUpdateParkingLot, useParkingLot } from "@/hooks/useParking";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const parkingFormSchema = z.object({
  parkingName: z.string().min(2, { message: "Name is required" }),
  location: z.string().min(2, { message: "Location is required" }),
  numberOfAvailableSpace: z.coerce
    .number()
    .min(1, { message: "Number of available spaces must be at least 1" }),
  feesPerHour: z.coerce
    .number()
    .min(0, { message: "Fees per hour cannot be negative" }),
});

type ParkingFormValues = z.infer<typeof parkingFormSchema>;

export function EditParking({
  open,
  openChange,
}: {
  open: boolean;
  openChange: (open: boolean) => void;
}) {
  const navigate = useNavigate();
  const { code } = useParams<{ code?: string }>();
  const isEditMode = !!code;

  const { data: parkingLot, isLoading } = useParkingLot(code || "");

  const createParkingLot = useCreateParkingLot();
  const updateParkingLot = useUpdateParkingLot();

  const form = useForm<ParkingFormValues>({
    resolver: zodResolver(parkingFormSchema),
    defaultValues: {
      parkingName: "",
      location: "",
      numberOfAvailableSpace: 1,
      feesPerHour: 0,
    },
  });

  useEffect(() => {
    if (parkingLot && isEditMode) {
      form.reset({
        parkingName: parkingLot.parkingName,
        location: parkingLot.location,
        numberOfAvailableSpace: parkingLot.numberOfAvailableSpace,
        feesPerHour: parkingLot.feesPerHour,
      });
    }
  }, [parkingLot, isEditMode, form]);

  const onSubmit = async (data: ParkingFormValues) => {
    try {
      if (isEditMode && code) {
        await updateParkingLot.mutateAsync({
          code,
          data: {
            parkingName: data.parkingName,
            location: data.location,
            numberOfAvailableSpace: data.numberOfAvailableSpace,
            feesPerHour: data.feesPerHour,
          },
        });
        toast.success("Parking lot updated successfully");
      } else {
        await createParkingLot.mutateAsync({
          parkingName: data.parkingName,
          location: data.location,
          numberOfAvailableSpace: data.numberOfAvailableSpace,
          feesPerHour: data.feesPerHour,
        });
        toast.success("Parking lot created successfully");
      }
      openChange(false);
      form.reset();
    } catch (error) {
      console.error("Failed to save parking lot:", error);
      toast.error("Failed to save parking lot");
    }
  };

  if (isLoading && isEditMode) {
    return <div>Loading...</div>;
  }

  return (
    <div className="max-h-[500px] overflow-auto">
      <Card className="border-none shadow-none mx-auto">
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="parkingName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Parking Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter parking name"
                        disabled={createParkingLot.isPending || updateParkingLot.isPending}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter location"
                        disabled={createParkingLot.isPending || updateParkingLot.isPending}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="numberOfAvailableSpace"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Available Spaces</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="1"
                          disabled={createParkingLot.isPending || updateParkingLot.isPending}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="feesPerHour"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Hourly Rate ($)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          step="0.01"
                          disabled={createParkingLot.isPending || updateParkingLot.isPending}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => openChange(false)}
                  disabled={createParkingLot.isPending || updateParkingLot.isPending}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createParkingLot.isPending || updateParkingLot.isPending}
                >
                  {createParkingLot.isPending || updateParkingLot.isPending
                    ? "Saving..."
                    : isEditMode
                    ? "Update Parking Lot"
                    : "Create Parking Lot"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
