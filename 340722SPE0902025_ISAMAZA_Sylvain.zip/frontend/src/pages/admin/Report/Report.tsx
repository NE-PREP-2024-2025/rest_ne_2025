import { useState, useMemo } from 'react';
import { PageHeader } from '@/components/CommonComponents/PageHeader';
import { useAllParkingTickets, useCarEntryReport, useCarExitReport } from '@/hooks/useParking';
import { DataTable, Column } from '@/components/DataTable/DataTable';
import { ParkingListParams, ParkingTicket } from '@/api/parkingApi';
import { Button } from '@/components/ui/button';
import { Download, RefreshCw, Filter } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

type ReportType = 'entry' | 'exit';

export default function Report() {
  const [activeTab, setActiveTab] = useState<ReportType>('entry');
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState('');
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });


  const queryParams: ParkingListParams = {
    page: pageIndex + 1,
    limit: pageSize,
    search,
    ...(dateRange?.from && { startDate: dateRange.from.toISOString() }),
    ...(dateRange?.to && { endDate: dateRange.to.toISOString() }),
  };

  // Fetch reports
  const {
    data: entryData,
    isLoading: isEntryLoading,
  
  } = useCarEntryReport(queryParams);

  const {
    data: exitData,
    isLoading: isExitLoading,
  } = useCarExitReport(queryParams);

  const currentData = activeTab === 'entry' ? entryData : exitData;
  const isLoading = activeTab === 'entry' ? isEntryLoading : isExitLoading;

  const columns: Column<ParkingTicket>[] = useMemo(
    () => [
      {
        header: 'Parking',
        accessorKey: 'parking_code',
        cell: (ticket) => (
          <div className="font-medium">{ticket.parking_code}</div>
        ),
      },
      {
        header: 'Plate Number',
        accessorKey: 'plateNumber',
        cell: (ticket) => (
          <div className="font-medium">{ticket.plateNumber}</div>
        ),
        sortable: true,
      },
      {
        header: 'Entry Time',
        accessorKey: 'entry_date',
        cell: (ticket) => (
          <div className="text-sm text-gray-500">
            {format(new Date(ticket.entry_date), 'PPpp')}
          </div>
        ),
        sortable: true,
      },
      {
        header: 'Exit Time',
        accessorKey: 'exit_date',
        cell: (ticket) => (
          <div className="text-sm text-gray-500">
            {ticket.exit_date ? format(new Date(ticket.exit_date), 'PPpp') : 'Active'}
          </div>
        ),
        sortable: true,
      },
      {
        header: 'Amount (RWF)',
        accessorKey: 'amount',
        cell: (ticket) => (
          <div className="font-medium">
            {ticket.amount ? `${ticket.amount.toLocaleString()}` : 'N/A'}
          </div>
        ),
        sortable: true,
      },
      {
        header: 'Duration',
        accessorKey: 'duration',
        cell: (ticket) => {
          if (!ticket.entry_date || !ticket.exit_date) return 'N/A';
          const diff = new Date(ticket.exit_date).getTime() - new Date(ticket.entry_date).getTime();
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          return `${hours}h ${minutes}m`;
        },
      },
    ],
    []
  );


  const handleTabChange = (value: string) => {
    setActiveTab(value as ReportType);
    setPageIndex(0); // Reset to first page when changing tabs
  };

  const handleDateRangeChange = (range: DateRange | undefined) => {
    setDateRange(range);
    setPageIndex(0); // Reset to first page when changing date range
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <PageHeader
            title="Parking Reports"
            description="View and manage parking ticket reports"
          />
        </div>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="entry">Entry Reports</TabsTrigger>
              <TabsTrigger value="exit">Exit Reports</TabsTrigger>
            </TabsList>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'justify-start text-left font-normal',
                    !dateRange && 'text-muted-foreground'
                  )}
                >
                  <Filter className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, 'LLL dd, y')} -{' '}
                        {format(dateRange.to, 'LLL dd, y')}
                      </>
                    ) : (
                      format(dateRange.from, 'LLL dd, y')
                    )
                  ) : (
                    <span>Pick a date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={handleDateRangeChange}
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>
          </div>

          <TabsContent value="entry" className="space-y-4">
            <DataTable
              columns={columns}
              data={entryData?.data || []}
              totalItems={entryData?.totalItems || 0}
              pageIndex={pageIndex}
              pageSize={pageSize}
              onPageChange={setPageIndex}
              onPageSizeChange={setPageSize}
              onSearch={setSearch}
              searchPlaceholder="Search entries..."
              isLoading={isEntryLoading}
            />
          </TabsContent>

          <TabsContent value="exit" className="space-y-4">
            <DataTable
              columns={columns}
              data={exitData?.data || []}
              totalItems={exitData?.totalItems || 0}
              pageIndex={pageIndex}
              pageSize={pageSize}
              onPageChange={setPageIndex}
              onPageSizeChange={setPageSize}
              onSearch={setSearch}
              searchPlaceholder="Search ..."
              isLoading={isExitLoading}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}