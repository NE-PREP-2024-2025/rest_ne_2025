import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/CommonComponents/PageHeader";
import {useDeleteParkingTicket, useParkingTickets } from "@/hooks/useParking";
import { DataTable, Column } from "@/components/DataTable/DataTable";
import { ParkingLot, ParkingTicket } from "@/api/parkingApi";
import { Button } from "@/components/ui/button";
import { Edit, Trash, ParkingCircle, Plus, Car, Clock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { toast } from "sonner";
import { CreateTicketModel } from "./CreateTicketModel";
function TicketList() {

  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [ticketToDelete, setTicketToDelete] = useState<ParkingTicket | null>(null);
  
  const deleteTicket = useDeleteParkingTicket();
   
  const { data, isLoading } = useParkingTickets({
    page: pageIndex + 1,
    limit: pageSize,
    search,
  });

  const handleDeleteClick = (ticket: ParkingTicket) => {
    setTicketToDelete(ticket);
  };
  
    
  


    const handleConfirmDelete = async () => {
      if (ticketToDelete) {
        try {
          await deleteTicket.mutateAsync(ticketToDelete.id);
          setTicketToDelete(null);
          toast.success('Ticket deleted successfully');
        } catch (error) {
          toast.error("Failed to delete ticket");
        }
      }
    };

    const handleCreateClick = () => {
      setIsCreateModalOpen(true);
    };

    const columns: Column<ParkingTicket>[] = [
      {
        header: "Plate Number",
        accessorKey: "plateNumber",
        cell: (ticket) => (
          <div className="flex items-center gap-2">
            <Car className="h-4 w-4" />
            <span className="font-medium">{ticket.plateNumber}</span>
          </div>
        ),
        sortable: true,
      },
      {
        header: "Parking Code",
        accessorKey: "parking_code",
        sortable: true,
        cell: (ticket) => (
          <div className="flex items-center gap-2">
            <ParkingCircle className="h-4 w-4" />
            <span className="font-medium">{ticket.parking_code}</span>
          </div>
        ),
      },
      {
        header: "Entry Date",
        accessorKey: "entry_date",
        sortable: true,
        cell: (ticket) => (
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span className="font-medium">{format(new Date(ticket.entry_date), 'PPpp')}</span>
          </div>
        ),  
      },
      {
        header: "Exit Date",
        accessorKey: "exit_date",
        sortable: true,
        cell: (ticket) => (
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span className="font-medium">{format(new Date(ticket.exit_date), 'PPpp') ?? "Not exited"}</span>
          </div>
        ),
      },
      {
        header: "Total Amount",
        accessorKey: "total_amount",
        cell: (ticket) => (
          <span>{ticket.amount.toFixed(2)} RWF</span>
        ),
        sortable: true,
      },
      {
        header: "Created",
        accessorKey: "createdAt",
        cell: (ticket) => format(new Date(ticket.createdAt), 'MMM d, yyyy'),
        sortable: true,
      },
      {
        header: "Actions",
        accessorKey: "actions",
        cell: (parking) => (
          <div className="flex items-center gap-2">
  
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                handleDeleteClick(parking);
              }}
            >
              <Trash className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        ),
      },
    ];

    return (
      <>
        <div className="container mx-auto py-6">
          <div className="flex justify-between items-center mb-6">
            <PageHeader
              title="Tickets"
              description="Manage tickets in the system"
            />
            <Button onClick={handleCreateClick}>
              <Plus className="mr-2 h-4 w-4" />
              Add Ticket
            </Button>
          </div>

          <DataTable
            columns={columns}
            data={data?.data || []}
            totalItems={data?.totalItems || 0}
            pageIndex={pageIndex}
            pageSize={pageSize}
            onPageChange={setPageIndex}
            onPageSizeChange={setPageSize}
            onSearch={setSearch}
            searchPlaceholder="Search tickets..."
            isLoading={isLoading}
          />
        </div>

        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogContent>
            <CreateTicketModel
              open={isCreateModalOpen}
              openChange={setIsCreateModalOpen}
            />
          </DialogContent>
        </Dialog>

        <Dialog
          open={!!ticketToDelete}
          onOpenChange={(open) => !open && setTicketToDelete(null)}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Parking Ticket</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete this parking ticket? This action cannot be
                undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setTicketToDelete(null)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleConfirmDelete}
                disabled={deleteTicket.isPending}
              >
                {deleteTicket.isPending ? "Deleting..." : "Delete"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </>
    );
  }



export default TicketList