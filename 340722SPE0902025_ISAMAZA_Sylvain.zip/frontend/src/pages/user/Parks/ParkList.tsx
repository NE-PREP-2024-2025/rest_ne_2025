import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/CommonComponents/PageHeader";
import { useParkingLots, useDeleteParkingLot } from "@/hooks/useParking";
import { DataTable, Column } from "@/components/DataTable/DataTable";
import { ParkingLot } from "@/api/parkingApi";
import { Button } from "@/components/ui/button";
import { Edit, Trash, ParkingCircle, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { toast } from "sonner";
import { CreateTicketModel } from "./CreateTicketModel";


export function UserParkingList() {
  const navigate = useNavigate();
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");
  const [createTicketModel, setCreateTicketModel] = useState<boolean>(false);
  const [parkingCode,setParkingCode]=useState("")
 
  const { data, isLoading } = useParkingLots({
    page: pageIndex + 1,
    limit: pageSize,
    search,
  });


  const columns: Column<ParkingLot>[] = [
    {
      header: "Code",
      accessorKey: "code",
      cell: (parking) => (
        <div className="flex items-center gap-2">
          <ParkingCircle className="h-4 w-4" />
          <span className="font-medium">{parking.code}</span>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Name",
      accessorKey: "parkingName",
      sortable: true,
    },
    {
      header: "Location",
      accessorKey: "location",
      sortable: true,
    },
    {
      header: "Available Spaces",
      accessorKey: "numberOfAvailableSpace",
      cell: (parking) => (
        <span className="font-medium">{parking.numberOfAvailableSpace}</span>
      ),
    },
    {
      header: "Hourly Rate",
      accessorKey: "feesPerHour",
      cell: (parking) => (
        <span>${parking.feesPerHour.toFixed(2)}</span>
      ),
      sortable: true,
    },
    {
      header: "Created",
      accessorKey: "createdAt",
      cell: (parking) => format(new Date(parking.createdAt), 'MMM d, yyyy'),
      sortable: true,
    },
    {
      header: "Actions",
      accessorKey: "actions",
      cell: (parking) => (
        <div className="flex items-center gap-2">
          <Button
          
            onClick={(e) => {
              e.stopPropagation();
              setParkingCode(parking.code);
              setCreateTicketModel(true);
            }}
          >
             Book Parking
          </Button>
        
        </div>
      ),
    },
  ];

  return (
    <>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <PageHeader
            title="Parking Lots"
            description="Manage parking lots in the system"
          />
        
        </div>
        <Dialog open={createTicketModel} onOpenChange={setCreateTicketModel}>
          <DialogContent>
        <CreateTicketModel parkingCode={parkingCode} open={createTicketModel} openChange={setCreateTicketModel}/>
          </DialogContent>
        </Dialog>

        <DataTable
          columns={columns}
          data={data?.data || []}
          totalItems={data?.totalItems || 0}
          pageIndex={pageIndex}
          pageSize={pageSize}
          onPageChange={setPageIndex}
          onPageSizeChange={setPageSize}
          onSearch={setSearch}
          searchPlaceholder="Search parking lots..."
          isLoading={isLoading}
        />
      </div>

     


    </>
  );
}
