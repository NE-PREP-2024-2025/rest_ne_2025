import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateParkingTicket } from "@/hooks/useParking";
import { useParkingLots } from "@/hooks/useParking";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const ticketFormSchema = z.object({
  plateNumber: z.string().min(2, { message: "Plate number is required" }),
  parkingCode: z.string().min(1, { message: "Please select a parking lot" }),
});

type TicketFormValues = z.infer<typeof ticketFormSchema>;

export function CreateTicketModel({
  open,
  parkingCode,
  openChange,
}: {
  open: boolean;
  parkingCode: string;
  openChange: (open: boolean) => void;
}) {
  const { data: parkingLotsData } = useParkingLots();
  const parkingLots = parkingLotsData?.data || [];
  
  const createTicket = useCreateParkingTicket();

  const form = useForm<TicketFormValues>({
    resolver: zodResolver(ticketFormSchema),
    defaultValues: {
      plateNumber: "",
      parkingCode: parkingCode,
    },
  });

  const onSubmit = async (data: TicketFormValues) => {
    try {
      await createTicket.mutateAsync({
        plateNumber: data.plateNumber,
        parkingCode: data.parkingCode,
      });
      
      toast.success("Ticket created successfully");
      openChange(false);
      form.reset();
    } catch (error) {
      console.error("Failed to create ticket:", error);
    }
  };

  return (
    <div className="max-h-[500px] overflow-auto">
      <Card className="border-none shadow-none mx-auto">
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="plateNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plate Number</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter plate number"
                        disabled={createTicket.isPending}
                        {...field}
                        className="uppercase"
                        onChange={(e) => {
                          field.onChange(e.target.value.toUpperCase());
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="parkingCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Parking Lot</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={createTicket.isPending}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a parking lot" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {parkingLots.map((lot) => (
                          <SelectItem key={lot.code} value={lot.code}>
                            {lot.parkingName} ({lot.code})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => openChange(false)}
                  disabled={createTicket.isPending}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createTicket.isPending}
                >
                  {createTicket.isPending ? "Creating..." : "Create Ticket"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
