# Frontend Application

## Project Overview
A modern web application built with React, TypeScript, Vite, and Tailwind CSS.

## Prerequisites
- Node.js (v18 or higher)
- npm (v9 or higher)
- Bun (optional, but recommended)

## Setup and Installation

1. Clone the repository
```bash
cd frontend
```

2. Install dependencies
```bash
npm install
# OR
bun install
```

## Development

### Running the Application
```bash
npm run dev
# OR
bun run dev
```
- Starts the development server
- Default port: 5173
- Open [http://localhost:5173](http://localhost:5173) in your browser

### Build for Production
```bash
npm run build
# OR
bun run build
```
- Compiles and minifies for production
- Output will be in the `dist/` directory

## Project Structure
- `src/`: Main application source code
  - `components/`: Reusable React components
  - `pages/`: Page-level components
  - `utils/`: Utility functions
  - `types/`: TypeScript type definitions
- `public/`: Static assets
- `tailwind.config.ts`: Tailwind CSS configuration
- `vite.config.ts`: Vite configuration

## Key Technologies
- React
- TypeScript
- Vite
- Tailwind CSS
- React Router
- Axios (for API calls)

## Expected Output
- Development server starts without errors
- Application loads in browser at `http://localhost:5173`
- Responsive design across different device sizes

## Troubleshooting
- Ensure all dependencies are installed correctly
- Check console for any error messages
- Verify backend service is running

## Code Quality
- ESLint for code linting
- Prettier for code formatting

## Deployment
Build the application and deploy the contents of the `dist/` directory to your preferred hosting platform.